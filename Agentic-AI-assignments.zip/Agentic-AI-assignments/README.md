# Agentic AI Assignments

Four agentic-AI builds covering no-code automation, chatbot design, Retrieval-Augmented Generation (RAG) and Multi-Agent Systems (MAS).

| # | Assignment | Tool | LLM used | Folder |
|---|---|---|---|---|
| 1 | Zapier – scheduled payment-reminder mail (CSV / sheet input) | Zapier Agents | Zapier Agents built-in model | [Assignment-1-Zapier-Payment-Reminder](./Assignment-1-Zapier-Payment-Reminder) |
| 2 | LangFlow – Smart chatbot (Market & Trend Sentiment) | LangFlow 1.12 | Groq · openai/gpt-oss-120b | [Assignment-2-LangFlow-Smart-Chatbot](./Assignment-2-LangFlow-Smart-Chatbot) |
| 3 | n8n + RAG – Credit Appraisal Policy chatbot | n8n (self-hosted) | Groq · openai/gpt-oss-120b + Ollama nomic-embed-text | [Assignment-3-n8n-RAG](./Assignment-3-n8n-RAG) |
| 4 | n8n + MAS – Study Assistant (central orchestrator) | n8n (self-hosted) | Groq · qwen/qwen3.8-27b, openai/gpt-oss-120b | [Assignment-4-n8n-MAS](./Assignment-4-n8n-MAS) |

Each folder contains a `README.md`, the prompts used (`Prompt(s).md`), the exported workflow / data files, and a `screenshots/` folder as proof of execution.

> No API keys are stored in this repository. Workflow exports reference credentials by name only; add your own keys after importing.
