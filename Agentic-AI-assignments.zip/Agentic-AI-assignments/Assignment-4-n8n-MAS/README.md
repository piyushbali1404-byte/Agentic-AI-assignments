# Assignment 4 – n8n Multi-Agent System: Study Assistant (Central Orchestrator)

**Tool:** n8n (self-hosted)  
**Pattern:** **Central** – one orchestrator agent routes each request to specialist agents exposed as tools.  
**LLMs used (Groq):**
| Agent | Model | Max tokens |
|---|---|---|
| Orchestrator | qwen/qwen3.8-27b | – |
| Case Summarizer | openai/gpt-oss-120b | 800 |
| PPT Creator | qwen/qwen3.8-27b | 900 |
| Question Bank | openai/gpt-oss-120b | 1200 |

## Agents
| Agent | Role |
|---|---|
| Orchestrator | Reads the request, decides which specialist(s) to call, returns their output |
| PPT Creator | 8–10 slide deck outline with bullets, speaker notes and visual suggestions |
| Case Summarizer | Structured case study: context, problem, key facts, analysis, outcome, lessons |
| Question Bank | 10 MCQs + 5 short-answer + 3 long/case questions, with answers |

## Flow
```
Chat Trigger → Orchestrator Agent (Groq + Simple Memory)
                 ├─ tool: PPT Creator Agent      (Groq)
                 ├─ tool: Case Summarizer Agent  (Groq)
                 └─ tool: Question Bank Agent    (Groq)
```

## Demonstration
| Request | Agent called by orchestrator | Screenshots |
|---|---|---|
| Make a question bank on Design Thinking | Question Bank | `01`, `02` |
| Create a case summary on Porter's Five Forces for the Indian EV two-wheeler market | Case Summarizer | `03`, `04` |
| Create PPT for Porter's Five Forces for the Indian EV two-wheeler market | PPT Creator | `05`, `06`, `07` |

The green path in each workflow screenshot shows which specialist the orchestrator invoked.

> Note: due to Groq free-tier limits (8K tokens/min per model), each specialist was demonstrated through a separate request. Asking for a "full study pack" makes the orchestrator call all three agents in sequence.

## How to run
1. Import `Study_Assistant_MAS.json` into n8n.
2. Select a Groq credential on all four Groq model nodes.
3. Open chat and send any of the requests above.

## Files
- `Study_Assistant_MAS.json` – n8n workflow export
- `Prompts.md` – all four agent system prompts + test prompts
- `screenshots/` – workflow routing and chat outputs for each agent
