# Assignment 1 – Zapier: Daily Pending Payment Reminder

**Tool:** Zapier Agents (Free plan)  
**LLM used:** Zapier Agents built-in model (managed by Zapier)  
**Trigger:** On Demand for testing (designed for a daily 9:00 AM schedule)  
**Integrations:** Google Sheets – Lookup Spreadsheet Rows (Advanced), Gmail – Send Email  
**Knowledge source:** Google Sheet `Zapier v0.1` (exported as `pending_payments.csv`)  

## Objective
Automatically scan an invoice sheet, find every row with `Status = Pending`, and email a payment reminder to the responsible person based on the invoice `Type`.

## Logic
| Condition | Action |
|---|---|
| Status ≠ Pending | Skip row (no email) |
| Type = Maintenance | Email Piyush |
| Type = Project | Email Aayush |

## Workflow
1. Trigger runs (on demand / daily schedule).
2. Agent reads all rows from the Google Sheet.
3. Filters rows where Status = Pending.
4. Reads Invoice ID, Type, Name, Amount, Bank name.
5. Routes the recipient by Type and sends one Gmail reminder per pending row.
6. Returns a summary of emails sent and rows skipped.

## Input data (`pending_payments.csv`)
| Invoice ID | Type | Name | Amount | Bank | Status |
|---|---|---|---|---|---|
| 101 | Maintenance | abc | 50,000 | Kotak | Pending |
| 102 | Maintenance | hari | 10,000 | HDFC | Pending |
| 103 | Project | ram | 2,000 | Kotak | Pending |
| 104 | Project | sunny | 7,000 | Axis | Completed |

## Result
3 pending invoices found → 3 reminder emails (101, 102 → Maintenance recipient; 103 → Project recipient). Invoice 104 skipped (Completed). Agent published as **v1**.

## Files
- `Prompt.md` – full agent instructions
- `pending_payments.csv` – input data
- `screenshots/`
  - `01_google_sheet_input.png` – source sheet
  - `02_agent_instructions.png` – agent instructions
  - `03_agent_tools_knowledge.png` – tools (Gmail, Google Sheets) + knowledge source
  - `04_preview_invoice_101.png`, `05_preview_invoice_103_recipient.png`, `06_preview_invoice_103_approve.png` – email previews generated from sheet data
  - `07_mail_received_invoice_102.png` – **proof of mail sent**
  - `08_agent_published.png` – agent published (v1)
