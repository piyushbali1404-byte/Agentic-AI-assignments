# Assignment 1 – Agent Prompt

**Tool:** Zapier Agents | **LLM:** Zapier Agents built-in model  
**Trigger:** On Demand (schedulable daily at 9:00 AM)  
**Tools:** Google Sheets – Lookup Spreadsheet Rows (Advanced), Gmail – Send Email  

## Instructions
```
Goal: Send payment reminder emails for every pending invoice in the Google Sheet "Zapier v0.1".

Steps:
1. Use Google Sheets: Lookup Spreadsheet Rows (Advanced) to read ALL rows from the sheet "Zapier v0.1" (Sheet1).
2. For each row, check the 'Status' column. If Status is not exactly "Pending", skip the row.
3. For each Pending row, read: Invoice ID, Type, Name, Amount, Bank name.
4. Decide the recipient by 'Type':
   - Type = "Maintenance" → send to Piyush
   - Type = "Project" → send to Aayush
5. Use Gmail: Send Email to send ONE email per pending row (do not create drafts, do not merge rows):

Subject: Payment Reminder – Invoice [Invoice ID] ([Type]) Pending

Dear [Piyush / Aayush],

This is a reminder that the following payment is pending:
- Invoice ID: [Invoice ID]
- Type: [Type]
- Payee Name: [Name]
- Amount Due: ₹[Amount]
- Bank: [Bank name]
- Status: Pending

Please process the payment at your earliest convenience. If already paid, please ignore this reminder.

Regards,
Accounts Team – Daily Pending Payment Reminder Agent

6. After all rows are processed, reply with a summary: how many emails were sent, to whom, and which invoice IDs were skipped.

Rules: Never send email for Completed rows. Never invent data; use only sheet values.
```

## Test prompt (Agent Preview)
`Run the pending payment reminders now`
