# Assignment 3 – n8n + RAG: Credit Appraisal Policy Chatbot

**Tool:** n8n (self-hosted, http://localhost:5678)  
**LLM used:** Groq – `openai/gpt-oss-120b` (AI Agent chat model)  
**Embeddings:** Ollama – `nomic-embed-text` (local)  
**Vector store:** n8n Simple Vector Store (in-memory, key `credit_kb`)  
**Knowledge base:** Credit Appraisal Policy & Loan Eligibility – Car Loan and Home Loan rules  

## Objective
A chatbot whose answers come **only** from the supplied policy document. If a question is outside the document (e.g. interest rate), it must say so instead of guessing.

## Workflow
**1. Ingestion (run once)**
```
Manual Trigger → Edit Fields (policy text) → Simple Vector Store (Insert, key: credit_kb)
                                               ├─ Default Data Loader (JSON) ← Recursive Text Splitter (500 / 50)
                                               └─ Embeddings Ollama (nomic-embed-text)
```
Result: policy split into **11 chunks** and embedded.

**2. Chat (RAG)**
```
Chat Trigger → AI Agent
                 ├─ Chat Model: Groq (openai/gpt-oss-120b)
                 ├─ Memory: Simple Memory
                 └─ Tool: Simple Vector Store (Retrieve as Tool "credit_policy_kb", top-k 4)
                              └─ Embeddings Ollama (nomic-embed-text)
```

## Sample Q&A
| Question | Answer |
|---|---|
| What is the maximum LTV for an electric car loan? | 85% (new battery-electric passenger vehicle) |
| Personal loan interest rate? | Not covered in the policy document. |

## How to run
1. `ollama pull nomic-embed-text`
2. Import `Credit_Appraisal_RAG_Chatbot.json` into n8n; add Groq and Ollama credentials.
3. Execute the **Manual Trigger (Ingest)** path once (in-memory store resets when n8n restarts).
4. Open chat and ask policy questions.

## Files
- `Credit_Appraisal_RAG_Chatbot.json` – n8n workflow export (policy text embedded in the Edit Fields node)
- `Credit_Appraisal_RAG_Knowledge_Base.docx` – original knowledge base
- `credit_appraisal_kb.txt` – plain-text version used for ingestion
- `Prompts.md` – agent system prompt, tool description, test questions
- `screenshots/`
  - `01_workflow.png` – full workflow (ingest + chat)
  - `02_vector_store_insert_11_chunks.png` – ingestion output
  - `03_chat_ltv_answer_with_logs.png` – grounded answer + agent → retrieval tool logs
  - `04_chat_not_covered.png` – out-of-scope question refused
  - `05_chat_path_tool_calls.png` – chat path execution
