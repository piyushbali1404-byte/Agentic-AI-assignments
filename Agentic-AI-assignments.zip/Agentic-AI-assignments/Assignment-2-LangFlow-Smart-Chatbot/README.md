# Assignment 2 – LangFlow Smart Chatbot: Market & Trend Sentiment Expert

**Tool:** LangFlow 1.12 (run locally via `uvx langflow run`, http://localhost:7861)  
**LLM used:** Groq – `openai/gpt-oss-120b` (connected through the OpenAI provider with base URL `https://api.groq.com/openai/v1`), temperature 0.1  
**Domain:** Market research / product sentiment analysis  

## Flow
```
Chat Input ──────────────► Language Model (Input)
Prompt Template ─────────► Language Model (System Message)
Language Model ──────────► Chat Output
```

## What it does
Acts as a market & trend expert: the user asks about a product or category and the bot returns an overall sentiment (positive / negative / mixed), key drivers, concerns and trend signals. If details are missing, it asks the user to describe the product or company.

## Sample results
- *"What is the current sentiment around electric scooters in India?"* → sentiment table (overall, social media, purchase intent, key concerns, regulatory) with a bottom-line summary.
- *"Customers say the new iPhone battery is weak but camera is great — classify the sentiment."* → **Mixed (neutral)**: camera = positive, battery = negative.

## How to run
1. `uvx --python 3.12 langflow run`
2. Import `Market_Sentiment_Chatbot.json`.
3. In the Language Model node, connect a provider (Groq key via the OpenAI provider, base URL above) and select `openai/gpt-oss-120b`.
4. Open **Playground** and chat.

## Files
- `Market_Sentiment_Chatbot.json` – exported LangFlow flow
- `Prompts.md` – system prompt, test prompts, LLM details
- `screenshots/`
  - `01_workflow.png` – flow canvas
  - `02_language_model_config.png` – model selection (gpt-oss-120b)
  - `03_output_ev_scooter_sentiment.png`, `04_output_iphone_sentiment.png` – Playground outputs
