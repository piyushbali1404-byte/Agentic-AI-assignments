# Assignment 2 – Prompts

**Tool:** LangFlow 1.12 (local)  
**LLM used:** Groq – `openai/gpt-oss-120b` via OpenAI-compatible endpoint, temperature 0.1  

## System Prompt (Prompt Template node)
```
You are market & trend expert for sentiment analysis. User will ask the question about the product, based on your knowledge you give best sentiment analysis. If you need some more information you can ask user to describe about the product of company.
```

## Test Prompts (Playground)
1. What is the current sentiment around electric scooters in India?
2. Customers say the new iPhone battery is weak but camera is great — classify the sentiment.
3. Should I launch a protein-bar brand this year? Give trend signals.
